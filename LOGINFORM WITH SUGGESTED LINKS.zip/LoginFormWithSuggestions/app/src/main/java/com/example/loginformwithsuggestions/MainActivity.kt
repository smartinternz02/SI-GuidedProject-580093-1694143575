package com.example.loginformwithothersuggestions
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.UriHandler
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.loginformwithsuggestions.R
import androidx.compose.ui.platform.LocalUriHandler as AndroidxComposeUiPlatformLocalUriHandler

@OptIn(ExperimentalComposeUiApi::class)
class LoginActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LoginScreen()
        }
    }
}

@OptIn(ExperimentalComposeUiApi::class, ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen() {
    var username by remember { mutableStateOf(TextFieldValue()) }
    var password by remember { mutableStateOf(TextFieldValue()) }
    val keyboardController = LocalSoftwareKeyboardController.current
    val uriHandler = AndroidxComposeUiPlatformLocalUriHandler.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {

        OutlinedTextField(
            value = username,
            onValueChange = { username = it },
            label = { Text(text = "Enter your username")},

            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
        )


        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            placeholder = { Text(text = "Enter your password") },
            label = { Text(stringResource(R.string.password)) },
            keyboardOptions = KeyboardOptions.Default.copy(
                keyboardType = KeyboardType.Password,
                imeAction = ImeAction.Done
            ),
            keyboardActions = KeyboardActions(
                onDone = {
                    keyboardController?.hide()
                }
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
        )


        SuggestWebsite(uriHandler)

        Button(
            onClick = {
                {/*TODO*/}
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
        ) {
            Text(text = stringResource(R.string.submit))
            Text(text="Submit")
        }
    }
}

@Composable
fun SuggestWebsite(uriHandler: UriHandler) {
    Spacer(modifier = Modifier.height(16.dp))

    Text(
        text = "Suggested Website Links:",
        style = TextStyle(fontSize = 18.sp, color = Color.Gray)
    )

    Spacer(modifier = Modifier.height(8.dp))
    val websiteLinks = listOf(
        "https://www.google.com",
        "https://www.youtube.com",
        "https://www.kotlinlang.org"
    )

    websiteLinks.forEach { link ->
        ClickableWebsiteLink(link = link, uriHandler = uriHandler)
    }
}

@Composable
fun ClickableWebsiteLink(link: String, uriHandler: UriHandler) {
    Text(
        text = link,
        color = Color.Blue,
        modifier = Modifier.clickable {
            val uri = Uri.parse(link)
            uriHandler.openUri(uri.toString())
        }
    )
}
@Preview(showBackground = true)
@Composable
fun PreviewLoginScreen() {
    LoginScreen()
}
