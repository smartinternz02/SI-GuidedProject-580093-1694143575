package com.dataflair.fooddeliveryapp.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.FrameLayout;

import com.dataflair.fooddeliveryapp.Fragments.AddItemFragment;
import com.dataflair.fooddeliveryapp.Fragments.AdminOrdersFragment;
import com.dataflair.fooddeliveryapp.Fragments.HomeFragment;
import com.dataflair.fooddeliveryapp.Fragments.MyOrdersFragment;
import com.dataflair.fooddeliveryapp.Fragments.UserProfileFragment;
import com.dataflair.fooddeliveryapp.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class AdminActivity extends AppCompatActivity {

    FrameLayout frameLayout;
    BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);


        frameLayout = (FrameLayout) findViewById(R.id.AdminFragmentContainer);

        bottomNavigationView = (BottomNavigationView) findViewById(R.id.AdminBottomNavigation);
        Menu menuNav = bottomNavigationView.getMenu();

        getSupportFragmentManager().beginTransaction().replace(R.id.AdminFragmentContainer, new AddItemFragment()).commit();

        bottomNavigationView.setOnNavigationItemSelectedListener(bottomNavigationMethod);
    }


    private BottomNavigationView.OnNavigationItemSelectedListener bottomNavigationMethod =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull @org.jetbrains.annotations.NotNull MenuItem item) {


                    Fragment fragment = null;
                    switch (item.getItemId()) {


                        case R.id.HomeMenu:
                            fragment = new AddItemFragment();
                            break;
                        case R.id.OrdersMenu:
                            fragment = new AdminOrdersFragment();
                            break;
                        case R.id.ProfileMenu:
                            fragment = new UserProfileFragment();
                            break;

                    }

                    getSupportFragmentManager().beginTransaction().replace(R.id.AdminFragmentContainer, fragment).commit();
                    return true;
                }
            };

}